### Server: https://discord.gg/onlp   
> :warning: **working again, if you don't have golang,**: you can directly run the compiled .exe in /executables         

code is from @Djuk1c that used my method and wrote it in golang

<!--
## Want Followers or Likes ?
- Join [discord.gg/onlp](https://discord.gg/onlp)
- 1k Followers = 3€ | 1k Likes = 2€

<h1 align="center">
  TikTok AIO 🪐
</h1>
<p align="center">
  TikTok AIO is available free in https://discord.gg/onlp
</p>
-->
<p align="center"> 
  <kbd>
<img src="https://cdn.discordapp.com/attachments/979841729538687017/980559718730833950/tiktok-loddgo-3.png"></img>
  </kbd>
</p>

<p align="center">
  <img src="https://img.shields.io/github/languages/top/xtekky/zefoy?style=flat-square" </a>
  <img src="https://img.shields.io/github/last-commit/xtekky/zefoy?style=flat-square" </a>
  <img src="https://img.shields.io/github/stars/xtekky/zefoy?color=7F9DE0&label=Stars&style=flat-square" </a>
  <img src="https://img.shields.io/github/forks/xtekky/zefoy?color=7F9DE0&label=Forks&style=flat-square" </a>
</p>

<h4 align="center">
  <a href="https://discord.gg/onlp">🌌・Discord</a>
  <a href="https://github.com/xtekky/zefoy#license">💻・License</a>
  <a href="https://github.com/xtekky/zefoy#changelog">📜・ChangeLog</a>
</h4>

<h2 align="center">
   TikTok AIO was made by

Love ❌ code ✅

</h2>

---

## :fire: Features

✔ Bot TikTok Followers, Likes, Views, Shares
✔ Free

---

## 🚀・Setup TikTok AIO

```sh-session
> Download python and install all requirements, go to discord.gg/onlp, download the script there and run it
```

## 🎉・Upcoming/enhancements

- Make it in python

## 📄・License

This project is licensed under the GPL General Public License v3.0 License - see the [LICENSE.md](./LICENSE) file for details
```js
  ・Educational purpose only and all your consequences caused by you actions is your responsibility
  ・Selling this Free AIO is forbidden
  ・If you make a copy of this/or fork it, it must be open-source and have credits linking to this repo
```

## 💭・ChangeLog

```diff
v1.0.0 ⋮ 2022-11-04
+ golang working version using requests

v0.0.2 ⋮ 2022-05-28
- removed open-source

v0.0.2 ⋮ 2022-03-28
+ added silent driver
+ added cleaner Log

v0.0.2 ⋮ 2022-03-28
+ cleaner code

v0.0.1 ⋮ 2022-03-28
+ Added Main Script
+ Cleaned up Code
```
